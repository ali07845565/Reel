import React, { useState } from 'react';
import {
  Container,
  Box,
  Typography,
  Stepper,
  Step,
  StepLabel,
  Paper,
  Alert,
} from '@mui/material';
import VideoUrlInput from './components/VideoUrlInput';
import LanguageSelector from './components/LanguageSelector';
import ProcessingStatus from './components/ProcessingStatus';
import ReelGallery from './components/ReelGallery';
import './App.css';

const steps = ['Paste YouTube URL', 'Select Language', 'Processing', 'Download Reels'];

function App() {
  const [activeStep, setActiveStep] = useState(0);
  const [jobId, setJobId] = useState(null);
  const [videoMetadata, setVideoMetadata] = useState(null);
  const [selectedLanguage, setSelectedLanguage] = useState('');
  const [reels, setReels] = useState([]);
  const [error, setError] = useState(null);

  const handleUrlSubmit = (id, metadata) => {
    setJobId(id);
    setVideoMetadata(metadata);
    setActiveStep(1);
    setError(null);
  };

  const handleLanguageSelect = (languageCode) => {
    setSelectedLanguage(languageCode);
    setActiveStep(2);
  };

  const handleProcessingComplete = (generatedReels) => {
    setReels(generatedReels);
    setActiveStep(3);
  };

  const handleProcessingError = (errorMessage) => {
    setError(errorMessage);
  };

  const handleReset = () => {
    setActiveStep(0);
    setJobId(null);
    setVideoMetadata(null);
    setSelectedLanguage('');
    setReels([]);
    setError(null);
  };

  const renderStepContent = () => {
    switch (activeStep) {
      case 0:
        return (
          <VideoUrlInput
            onSubmit={handleUrlSubmit}
            onError={handleProcessingError}
          />
        );
      case 1:
        return (
          <LanguageSelector
            jobId={jobId}
            metadata={videoMetadata}
            onSelect={handleLanguageSelect}
            onError={handleProcessingError}
          />
        );
      case 2:
        return (
          <ProcessingStatus
            jobId={jobId}
            language={selectedLanguage}
            onComplete={handleProcessingComplete}
            onError={handleProcessingError}
          />
        );
      case 3:
        return (
          <ReelGallery
            reels={reels}
            onReset={handleReset}
          />
        );
      default:
        return null;
    }
  };

  return (
    <Container maxWidth="md" sx={{ py: 4 }}>
      <Box sx={{ mb: 4, textAlign: 'center' }}>
        <Typography variant="h3" component="h1" gutterBottom sx={{ fontWeight: 'bold' }}>
          Viral Reel Generator
        </Typography>
        <Typography variant="subtitle1" color="text.secondary">
          AI-Powered Multi-Lingual Viral Reel Generator
        </Typography>
      </Box>

      <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
        <Stepper activeStep={activeStep} alternativeLabel>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
      </Paper>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      <Paper elevation={3} sx={{ p: 4, minHeight: 400 }}>
        {renderStepContent()}
      </Paper>

      <Box sx={{ mt: 4, textAlign: 'center', color: 'text.secondary' }}>
        <Typography variant="body2">
          Powered by OpenAI Whisper, GPT-4o, and MediaPipe
        </Typography>
      </Box>
    </Container>
  );
}

export default App;
