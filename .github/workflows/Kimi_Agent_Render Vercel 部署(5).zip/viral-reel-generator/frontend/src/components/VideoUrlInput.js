import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  Typography,
  CircularProgress,
  Card,
  CardMedia,
  CardContent,
  Chip,
} from '@mui/material';
import { YouTube, ArrowForward } from '@mui/icons-material';
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

function VideoUrlInput({ onSubmit, onError }) {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState(null);

  const isValidYouTubeUrl = (url) => {
    const patterns = [
      /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
    ];
    return patterns.some((pattern) => pattern.test(url));
  };

  const handleFetchMetadata = async () => {
    if (!isValidYouTubeUrl(url)) {
      onError('Please enter a valid YouTube URL');
      return;
    }

    setLoading(true);
    setPreview(null);

    try {
      const response = await axios.post(`${API_BASE_URL}/api/v1/videos/fetch-metadata`, {
        url: url,
      });

      const { job_id, metadata } = response.data;
      setPreview({ job_id, metadata });
    } catch (error) {
      onError(error.response?.data?.detail || 'Failed to fetch video metadata');
    } finally {
      setLoading(false);
    }
  };

  const handleContinue = () => {
    if (preview) {
      onSubmit(preview.job_id, preview.metadata);
    }
  };

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatViewCount = (count) => {
    if (!count) return 'N/A';
    if (count >= 1000000) {
      return `${(count / 1000000).toFixed(1)}M`;
    }
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}K`;
    }
    return count.toString();
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom align="center">
        Enter YouTube Video URL
      </Typography>

      <Typography variant="body2" color="text.secondary" align="center" sx={{ mb: 3 }}>
        Paste a YouTube video link to extract viral moments and generate reels
      </Typography>

      <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
        <TextField
          fullWidth
          variant="outlined"
          placeholder="https://www.youtube.com/watch?v=..."
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          disabled={loading}
          InputProps={{
            startAdornment: <YouTube sx={{ mr: 1, color: 'error.main' }} />,
          }}
        />
        <Button
          variant="contained"
          onClick={handleFetchMetadata}
          disabled={loading || !url}
          sx={{ minWidth: 120 }}
        >
          {loading ? <CircularProgress size={24} /> : 'Fetch'}
        </Button>
      </Box>

      {preview && (
        <Card sx={{ mt: 3 }}>
          <CardMedia
            component="img"
            height="240"
            image={preview.metadata.thumbnail_url}
            alt={preview.metadata.title}
          />
          <CardContent>
            <Typography variant="h6" gutterBottom>
              {preview.metadata.title}
            </Typography>

            <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap', mb: 2 }}>
              <Chip
                label={`Duration: ${preview.metadata.duration_string}`}
                size="small"
                color="primary"
              />
              <Chip
                label={`Views: ${formatViewCount(preview.metadata.view_count)}`}
                size="small"
                variant="outlined"
              />
              {preview.metadata.uploader && (
                <Chip
                  label={`Channel: ${preview.metadata.uploader}`}
                  size="small"
                  variant="outlined"
                />
              )}
            </Box>

            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              {preview.metadata.description?.substring(0, 200)}
              {preview.metadata.description?.length > 200 ? '...' : ''}
            </Typography>

            <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
              <Button
                variant="contained"
                color="primary"
                onClick={handleContinue}
                endIcon={<ArrowForward />}
              >
                Continue
              </Button>
            </Box>
          </CardContent>
        </Card>
      )}

      <Box sx={{ mt: 3, p: 2, bgcolor: 'background.paper', borderRadius: 1 }}>
        <Typography variant="subtitle2" gutterBottom>
          Supported Features:
        </Typography>
        <Typography variant="body2" color="text.secondary" component="div">
          <ul style={{ margin: 0, paddingLeft: 20 }}>
            <li>Multi-language audio track detection</li>
            <li>AI-powered viral moment detection</li>
            <li>Face-tracking smart cropping (16:9 → 9:16)</li>
            <li>Dynamic animated captions</li>
          </ul>
        </Typography>
      </Box>
    </Box>
  );
}

export default VideoUrlInput;
