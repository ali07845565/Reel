import React, { useEffect, useState, useRef } from 'react';
import {
  Box,
  Typography,
  LinearProgress,
  Stepper,
  Step,
  StepLabel,
  Card,
  CardContent,
  Chip,
  Fade,
} from '@mui/material';
import {
  CloudDownload,
  RecordVoiceOver,
  Psychology,
  VideoSettings,
  CheckCircle,
  Error as ErrorIcon,
} from '@mui/icons-material';
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const processingSteps = [
  { label: 'Downloading', icon: CloudDownload, status: 'downloading' },
  { label: 'Transcribing', icon: RecordVoiceOver, status: 'transcribing' },
  { label: 'AI Analysis', icon: Psychology, status: 'analyzing' },
  { label: 'Generating Reels', icon: VideoSettings, status: 'processing' },
];

function ProcessingStatus({ jobId, language, onComplete, onError }) {
  const [status, setStatus] = useState('downloading');
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState(null);
  const [viralMoments, setViralMoments] = useState([]);
  const wsRef = useRef(null);

  useEffect(() => {
    // Connect to WebSocket for real-time updates
    const connectWebSocket = () => {
      const wsUrl = API_BASE_URL.replace('http', 'ws');
      wsRef.current = new WebSocket(`${wsUrl}/ws/jobs/${jobId}`);

      wsRef.current.onopen = () => {
        console.log('WebSocket connected');
      };

      wsRef.current.onmessage = (event) => {
        const data = JSON.parse(event.data);
        setStatus(data.status);
        setProgress(data.progress);

        if (data.status === 'completed') {
          fetchReels();
        } else if (data.status === 'failed') {
          setError(data.message);
          onError(data.message);
        }
      };

      wsRef.current.onerror = (error) => {
        console.error('WebSocket error:', error);
        // Fall back to polling
        startPolling();
      };

      wsRef.current.onclose = () => {
        console.log('WebSocket disconnected');
      };
    };

    // Fallback polling
    const startPolling = () => {
      const interval = setInterval(async () => {
        try {
          const response = await axios.get(`${API_BASE_URL}/api/v1/videos/status/${jobId}`);
          const data = response.data;

          setStatus(data.status);
          setProgress(data.progress);

          if (data.status === 'completed') {
            clearInterval(interval);
            fetchReels();
          } else if (data.status === 'failed') {
            clearInterval(interval);
            setError(data.message);
            onError(data.message);
          }
        } catch (err) {
          console.error('Polling error:', err);
        }
      }, 2000);

      return () => clearInterval(interval);
    };

    connectWebSocket();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [jobId]);

  const fetchReels = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/v1/videos/reels/${jobId}`);
      const reels = response.data.reels;
      setViralMoments(reels);
      onComplete(reels);
    } catch (err) {
      onError('Failed to fetch generated reels');
    }
  };

  const getActiveStep = () => {
    const stepIndex = processingSteps.findIndex((s) => s.status === status);
    return stepIndex >= 0 ? stepIndex : 0;
  };

  const getStatusIcon = (stepStatus) => {
    if (status === 'failed') {
      return <ErrorIcon color="error" />;
    }
    if (stepStatus === status) {
      return <processingSteps.find((s) => s.status === stepStatus)?.icon />;
    }
    const stepIndex = processingSteps.findIndex((s) => s.status === stepStatus);
    const currentIndex = processingSteps.findIndex((s) => s.status === status);
    if (stepIndex < currentIndex) {
      return <CheckCircle color="success" />;
    }
    return <processingSteps.find((s) => s.status === stepStatus)?.icon />;
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom align="center">
        Processing Video
      </Typography>

      <Typography variant="body2" color="text.secondary" align="center" sx={{ mb: 3 }}>
        Our AI is analyzing your video to find the most viral moments
      </Typography>

      <Box sx={{ mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
          <Typography variant="body2" color="text.secondary">
            Progress
          </Typography>
          <Typography variant="body2" color="primary">
            {progress}%
          </Typography>
        </Box>
        <LinearProgress
          variant="determinate"
          value={progress}
          sx={{
            height: 10,
            borderRadius: 5,
            backgroundColor: 'rgba(255, 107, 53, 0.2)',
            '& .MuiLinearProgress-bar': {
              background: 'linear-gradient(90deg, #FF6B35 0%, #4ECDC4 100%)',
              borderRadius: 5,
            },
          }}
        />
      </Box>

      <Stepper activeStep={getActiveStep()} orientation="vertical" sx={{ mb: 4 }}>
        {processingSteps.map((step, index) => (
          <Step key={step.label} completed={index < getActiveStep()}>
            <StepLabel
              StepIconComponent={() => (
                <Box
                  sx={{
                    width: 32,
                    height: 32,
                    borderRadius: '50%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    bgcolor: index <= getActiveStep() ? 'primary.main' : 'grey.700',
                    color: 'white',
                  }}
                >
                  {getStatusIcon(step.status)}
                </Box>
              )}
            >
              <Typography
                variant="body1"
                sx={{
                  fontWeight: index === getActiveStep() ? 'bold' : 'normal',
                  color: index === getActiveStep() ? 'primary.main' : 'inherit',
                }}
              >
                {step.label}
              </Typography>
            </StepLabel>
          </Step>
        ))}
      </Stepper>

      {status === 'analyzing' && viralMoments.length === 0 && (
        <Fade in>
          <Card sx={{ mb: 3, bgcolor: 'background.paper' }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                What our AI is looking for:
              </Typography>
              <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                <Chip label="Attention Hooks" color="primary" size="small" />
                <Chip label="Climax Moments" color="secondary" size="small" />
                <Chip label="High-Value Insights" color="info" size="small" />
                <Chip label="Emotional Peaks" color="success" size="small" />
                <Chip label="Laughter Detection" color="warning" size="small" />
              </Box>
            </CardContent>
          </Card>
        </Fade>
      )}

      {status === 'processing' && (
        <Fade in>
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Generating Your Reels
              </Typography>
              <Typography variant="body2" color="text.secondary">
                • Converting to 9:16 vertical format with face tracking
              </Typography>
              <Typography variant="body2" color="text.secondary">
                • Adding animated captions
              </Typography>
              <Typography variant="body2" color="text.secondary">
                • Optimizing for social media platforms
              </Typography>
            </CardContent>
          </Card>
        </Fade>
      )}

      {error && (
        <Card sx={{ bgcolor: 'error.dark', mb: 3 }}>
          <CardContent>
            <Typography variant="h6" color="error.contrastText">
              Processing Failed
            </Typography>
            <Typography variant="body2" color="error.contrastText">
              {error}
            </Typography>
          </CardContent>
        </Card>
      )}

      <Typography variant="caption" color="text.secondary" align="center" display="block">
        Job ID: {jobId}
      </Typography>
    </Box>
  );
}

export default ProcessingStatus;
