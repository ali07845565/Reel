import React from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Chip,
  IconButton,
  Tooltip,
  Divider,
} from '@mui/material';
import {
  Download,
  PlayArrow,
  Refresh,
  Share,
  Timer,
  TrendingUp,
  Lightbulb,
  EmojiEmotions,
} from '@mui/icons-material';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

function ReelGallery({ reels, onReset }) {
  const getHookTypeIcon = (type) => {
    switch (type) {
      case 'hook':
        return <TrendingUp fontSize="small" />;
      case 'climax':
        return <PlayArrow fontSize="small" />;
      case 'insight':
        return <Lightbulb fontSize="small" />;
      case 'emotional':
        return <EmojiEmotions fontSize="small" />;
      default:
        return <PlayArrow fontSize="small" />;
    }
  };

  const getHookTypeColor = (type) => {
    switch (type) {
      case 'hook':
        return 'primary';
      case 'climax':
        return 'secondary';
      case 'insight':
        return 'info';
      case 'emotional':
        return 'success';
      default:
        return 'default';
    }
  };

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleDownload = (reel) => {
    const downloadUrl = `${API_BASE_URL}${reel.video_url}`;
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = `viral_reel_${reel.reel_id}.mp4`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShare = async (reel) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Viral Reel',
          text: reel.hook_text,
          url: `${API_BASE_URL}${reel.video_url}`,
        });
      } catch (err) {
        console.log('Share cancelled');
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(`${API_BASE_URL}${reel.video_url}`);
      alert('Link copied to clipboard!');
    }
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom align="center">
        Your Viral Reels Are Ready!
      </Typography>

      <Typography variant="body2" color="text.secondary" align="center" sx={{ mb: 3 }}>
        We found {reels.length} high-potential viral moments in your video
      </Typography>

      <Grid container spacing={3}>
        {reels.map((reel, index) => (
          <Grid item xs={12} md={6} key={reel.reel_id}>
            <Card className="reel-card" sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
              {/* Video Preview */}
              <Box sx={{ position: 'relative', bgcolor: 'black', height: 400 }}>
                <video
                  src={`${API_BASE_URL}${reel.video_url}`}
                  style={{
                    width: '100%',
                    height: '100%',
                    objectFit: 'contain',
                  }}
                  controls
                  poster={reel.thumbnail_url}
                />
                <Box
                  sx={{
                    position: 'absolute',
                    top: 8,
                    left: 8,
                    bgcolor: 'rgba(0,0,0,0.7)',
                    borderRadius: 1,
                    px: 1,
                  }}
                >
                  <Typography variant="caption" color="white">
                    #{index + 1}
                  </Typography>
                </Box>
              </Box>

              <CardContent sx={{ flexGrow: 1 }}>
                {/* Hook Type Badge */}
                <Box sx={{ mb: 2 }}>
                  <Chip
                    icon={getHookTypeIcon(reel.hook_type)}
                    label={reel.hook_type?.toUpperCase() || 'MOMENT'}
                    color={getHookTypeColor(reel.hook_type)}
                    size="small"
                    sx={{ mr: 1 }}
                  />
                  <Chip
                    icon={<Timer fontSize="small" />}
                    label={formatDuration(reel.duration)}
                    size="small"
                    variant="outlined"
                  />
                </Box>

                {/* Hook Text */}
                <Typography variant="h6" gutterBottom sx={{ fontSize: '1.1rem' }}>
                  "{reel.hook_text}"
                </Typography>

                {/* Confidence Score */}
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <TrendingUp fontSize="small" sx={{ mr: 0.5, color: 'success.main' }} />
                  <Typography variant="body2" color="success.main">
                    Viral Score: {(reel.confidence_score * 100).toFixed(0)}%
                  </Typography>
                </Box>

                {/* Timestamp */}
                <Typography variant="caption" color="text.secondary">
                  From {formatDuration(reel.start_time)} to {formatDuration(reel.end_time)}
                </Typography>

                {reel.file_size && (
                  <Typography variant="caption" color="text.secondary" display="block">
                    Size: {(reel.file_size / 1024 / 1024).toFixed(2)} MB
                  </Typography>
                )}
              </CardContent>

              <Divider />

              <CardActions sx={{ justifyContent: 'space-between' }}>
                <Box>
                  <Tooltip title="Download">
                    <IconButton
                      color="primary"
                      onClick={() => handleDownload(reel)}
                    >
                      <Download />
                    </IconButton>
                  </Tooltip>
                  <Tooltip title="Share">
                    <IconButton onClick={() => handleShare(reel)}>
                      <Share />
                    </IconButton>
                  </Tooltip>
                </Box>
                <Button
                  variant="contained"
                  size="small"
                  startIcon={<Download />}
                  onClick={() => handleDownload(reel)}
                >
                  Download
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Summary Stats */}
      {reels.length > 0 && (
        <Card sx={{ mt: 4, bgcolor: 'background.paper' }}>
          <CardContent>
            <Typography variant="h6" gutterBottom>
              Summary
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={6} md={3}>
                <Typography variant="h4" color="primary">
                  {reels.length}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Reels Generated
                </Typography>
              </Grid>
              <Grid item xs={6} md={3}>
                <Typography variant="h4" color="primary">
                  {(reels.reduce((acc, r) => acc + r.confidence_score, 0) / reels.length * 100).toFixed(0)}%
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Avg Viral Score
                </Typography>
              </Grid>
              <Grid item xs={6} md={3}>
                <Typography variant="h4" color="primary">
                  {formatDuration(reels.reduce((acc, r) => acc + r.duration, 0))}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Total Duration
                </Typography>
              </Grid>
              <Grid item xs={6} md={3}>
                <Typography variant="h4" color="primary">
                  {(reels.reduce((acc, r) => acc + (r.file_size || 0), 0) / 1024 / 1024).toFixed(1)} MB
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Total Size
                </Typography>
              </Grid>
            </Grid>
          </CardContent>
        </Card>
      )}

      {/* Process Another Button */}
      <Box sx={{ mt: 4, textAlign: 'center' }}>
        <Button
          variant="outlined"
          size="large"
          startIcon={<Refresh />}
          onClick={onReset}
        >
          Process Another Video
        </Button>
      </Box>
    </Box>
  );
}

export default ReelGallery;
