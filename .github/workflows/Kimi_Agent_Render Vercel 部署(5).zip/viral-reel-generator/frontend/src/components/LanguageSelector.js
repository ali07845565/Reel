import React, { useState } from 'react';
import {
  Box,
  Typography,
  Button,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Card,
  CardContent,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Radio,
  Divider,
  Alert,
  Slider,
} from '@mui/material';
import {
  Language,
  Settings,
  ArrowBack,
  PlayArrow,
} from '@mui/icons-material';
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

function LanguageSelector({ jobId, metadata, onSelect, onError }) {
  const [selectedLanguage, setSelectedLanguage] = useState('');
  const [numReels, setNumReels] = useState(5);
  const [reelDuration, setReelDuration] = useState(60);
  const [loading, setLoading] = useState(false);

  const handleStartProcessing = async () => {
    if (!selectedLanguage) {
      onError('Please select a language');
      return;
    }

    setLoading(true);

    try {
      await axios.post(`${API_BASE_URL}/api/v1/videos/process`, {
        job_id: jobId,
        language_code: selectedLanguage,
        num_reels: numReels,
        reel_duration: reelDuration,
      });

      onSelect(selectedLanguage);
    } catch (error) {
      onError(error.response?.data?.detail || 'Failed to start processing');
    } finally {
      setLoading(false);
    }
  };

  const getLanguageFlag = (code) => {
    const flags = {
      en: '🇺🇸',
      es: '🇪🇸',
      fr: '🇫🇷',
      de: '🇩🇪',
      it: '🇮🇹',
      pt: '🇧🇷',
      ru: '🇷🇺',
      ja: '🇯🇵',
      ko: '🇰🇷',
      zh: '🇨🇳',
      'zh-Hans': '🇨🇳',
      'zh-Hant': '🇹🇼',
      hi: '🇮🇳',
      ar: '🇸🇦',
      tr: '🇹🇷',
      unknown: '🎵',
    };
    return flags[code] || '🌐';
  };

  return (
    <Box>
      <Typography variant="h5" gutterBottom align="center">
        Select Audio Language
      </Typography>

      <Typography variant="body2" color="text.secondary" align="center" sx={{ mb: 3 }}>
        Choose the language for audio processing and caption generation
      </Typography>

      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
            <Language sx={{ mr: 1 }} />
            Available Languages
          </Typography>

          <List>
            {metadata.available_languages.map((lang) => (
              <ListItem
                key={lang.language}
                button
                selected={selectedLanguage === lang.language}
                onClick={() => setSelectedLanguage(lang.language)}
              >
                <ListItemIcon>
                  <Radio checked={selectedLanguage === lang.language} />
                </ListItemIcon>
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <span style={{ fontSize: '1.5rem' }}>
                        {getLanguageFlag(lang.language)}
                      </span>
                      <span>{lang.language_name}</span>
                      {lang.is_original && (
                        <span style={{ color: '#4ECDC4', fontSize: '0.8rem' }}>
                          (Original)
                        </span>
                      )}
                    </Box>
                  }
                  secondary={
                    lang.bitrate && `Bitrate: ${lang.bitrate}kbps • Codec: ${lang.codec || 'N/A'}`
                  }
                />
              </ListItem>
            ))}
          </List>

          {!metadata.available_languages?.length && (
            <Alert severity="info" sx={{ mt: 2 }}>
              No language tracks detected. The original audio will be used.
            </Alert>
          )}
        </CardContent>
      </Card>

      <Card sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="h6" gutterBottom sx={{ display: 'flex', alignItems: 'center' }}>
            <Settings sx={{ mr: 1 }} />
            Processing Options
          </Typography>

          <Box sx={{ px: 2 }}>
            <Typography variant="subtitle2" gutterBottom>
              Number of Reels: {numReels}
            </Typography>
            <Slider
              value={numReels}
              onChange={(e, value) => setNumReels(value)}
              min={1}
              max={10}
              marks
              valueLabelDisplay="auto"
              sx={{ mb: 3 }}
            />

            <Typography variant="subtitle2" gutterBottom>
              Target Reel Duration: {reelDuration} seconds
            </Typography>
            <Slider
              value={reelDuration}
              onChange={(e, value) => setReelDuration(value)}
              min={30}
              max={90}
              step={5}
              marks={[
                { value: 30, label: '30s' },
                { value: 60, label: '60s' },
                { value: 90, label: '90s' },
              ]}
              valueLabelDisplay="auto"
            />
          </Box>
        </CardContent>
      </Card>

      <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
        <Button
          variant="outlined"
          startIcon={<ArrowBack />}
          onClick={() => window.location.reload()}
        >
          Back
        </Button>
        <Button
          variant="contained"
          color="primary"
          onClick={handleStartProcessing}
          disabled={!selectedLanguage || loading}
          startIcon={<PlayArrow />}
        >
          {loading ? 'Starting...' : 'Start Processing'}
        </Button>
      </Box>
    </Box>
  );
}

export default LanguageSelector;
